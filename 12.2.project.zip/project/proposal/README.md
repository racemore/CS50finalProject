# Proposal

## What will (likely) be the title of your project?

WeebTube

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

The project is a website that rates and recommends anime based on the user. People will have their own profile with a history of recommendations and have their favorite shows on display for other users to see.

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

For the project, we will be using Flask, Python, SQL, and fundamental website tools - HTML, CSS, JavaScript. After registering and logging in, the user has access to several community features and customization over their profile page. In particular, the user should be able to rate an anime show out of 10 points, and we will use the SQL database to generate the top 10 shows the user watched on their profile page. Based on their history and ratings, the website will generate a list of recommendations for other shows the user should watch. Lastly, there will be an additional page with the top 10-20 shows based on all users of the site.

## If planning to combine CS50's final project with another course's final project, with which other course? And which aspect(s) of your proposed project would relate to CS50, and which aspect(s) would relate to the other course?

NOT APPLICABLE

## If planning to collaborate with 1 or 2 classmates for the final project, list their names, email addresses, and the names of their assigned TFs below.

Ashleigh Coltman, ashleighcoltman@college.harvard.edu, TF: Ashley Zhuang
Aracely Moreno, amoreno1@college.harvard.edu, TF: Jonny Zhang

## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

Login page, Create account, Change Password, Rate a show and displays rating history, Overall Rating page with top 10 for all users

### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

This outcome will include all implementations of the GOOD outcome along with the following features: improved design/ layout (beyond the Finance problem set), profile page (which contains history of shows watched, display personal top 10 shows), and enhanced password settings (which sends the user an email with a no time limit temporary password to login and change their password if requested)

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

This outcome will include all implementations of the GOOD/BETTER outcome along with the following features: page to schedule a watch party with other users and send requests to specific users given their usernames. Users that confirm their invitation will be sent an email with a link to a video-sharing website, like kosomi.io, when the watch party event occurs.

## In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one of two classmates, who will do what?

First, we will try using Visual Studio Code's Live Share feature to collaborate on web development. If an issue arises, we will switch to CS50's IDE and share our scripts through git and GitHub, which we will learn how to effectively use. As for the website itself, we will both create the basic layout of the website, likely adapting features like the login page of Finance. If time permits, one of us will work on improving the design or layout of the pages. After the login and register pages are set, Aracely will work on the profile page of the registered user. This page will contain the user's rating history and recommended shows to watch.
I will work on analyzing the data from https://www.kaggle.com/azathoth42/myanimelist to generate the list of anime shows available to rate on the website. I will then create another page that will generate an updated list of the top-rated shows based on all the users of the website. If either of us needs assistance, we will pitch in, and, if time permits, we will create the watch party request page. Watch parties allow users to watch a video and communicate at the same time, so to do this, we will likely send the users a link to an external, popular video-sharing website unless we research a safe way to do so within our site.

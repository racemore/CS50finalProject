import os
import docker

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from flask_mail import Mail, Message

from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, standard_date
from datetime import date, datetime

from password_generator import PasswordGenerator

# Configure application
app = Flask(__name__)


# Configure gmail services ** FROM WEEK 9 NOTES **
app.config["MAIL_DEFAULT_SENDER"] = os.getenv("MAIL_DEFAULT_SENDER")
app.config["MAIL_PASSWORD"] = os.getenv("MAIL_PASSWORD")
app.config["MAIL_PASSWORD"] = "weebtube234"
app.config["MAIL_PORT"] = 587
app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_USE_TLS"] = True
app.config["MAIL_USERNAME"] = os.getenv("MAIL_USERNAME")
mail = Mail(app)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True


# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure WeebTube Library to use SQLite database
db = SQL("sqlite:///weebtube.db")

# Number of favorites a user can have
MAX_FAVORITES = 20

# List of genders a user can choose from
GENDERS = ['Male', 'Female', 'Non-Binary', 'Agender', 'Prefer not to say']

CURRENT_DATE = date.today()


@app.route("/inbox")
@login_required
def inbox():
    # TODO
    # User's id
    user_id = session.get("user_id")

    # List of users who have requested to become friends
    friend_requests = db.execute("""SELECT users.username, users.pfp_url, users.id, friends.friend_date
                                 FROM users JOIN friends ON users.id = friends.user_id
                                 WHERE friends.friend_id = ? AND friends.pending = 1
                                 ORDER BY friends.friend_date DESC""", user_id)

    return render_template("inbox.html", friend_requests=friend_requests)


@app.route("/friend-requests", methods=["GET", "POST"])
@login_required
def friendRequests():
    """Answer friend requests"""

    # User's id
    user_id = session.get("user_id")
    if request.method == "GET":

        # User reached route via GET
        return redirect("inbox")

    if request.method == "POST":

        # Retrieve id of user who sent request
        requester_id = request.form.get("request")

        # Username of requester
        requester_name = db.execute("SELECT username FROM users WHERE id = ?", requester_id)[0]['username']

        # Check if user declined request; delete request from database
        if request.form.get("response") == "decline":
            db.execute("DELETE FROM friends WHERE user_id = ? AND friend_id = ?", requester_id, user_id)

            flash("Request declined", 'success')
            return redirect("/inbox")

        # Update databse to reflect that the two users are now friends
        db.execute("UPDATE friends SET pending = 0, friend_date = ? WHERE user_id = ? AND friend_id = ?", datetime.now(), requester_id, user_id)
        db.execute("INSERT INTO friends (user_id, friend_id, pending) VALUES(?, ?, 0)", user_id, requester_id)

        flash("You are now friends with " + requester_name + "!", 'success')
        return redirect("/inbox")


@app.route("/remove-friend", methods=["GET", "POST"])
@login_required
def removeFriend():
    """Remove friend"""

    # User ID
    user_id = session.get("user_id")

    if request.method == "GET":

        return redirect("/friends")

    if request.method == "POST":

        # ID/name of friend to remove
        friend_id = request.form.get("remove_friend")
        friend_name = db.execute("SELECT username FROM users WHERE id = ?", friend_id)[0]['username']

        # Delete corresponding entry from friends table
        db.execute("DELETE FROM friends WHERE user_id = ? AND friend_id = ?", user_id, friend_id)
        db.execute("DELETE FROM friends WHERE user_id = ? AND friend_id = ?", friend_id, user_id)

        flash("You are no longer friends with " + friend_name + "!", 'success')

        return redirect("/friends")


@app.route("/friends", methods=["GET", "POST"])
@login_required
def friends():
    """Display friend list and add friends"""

    user_id = session.get("user_id")
    if request.method == "GET":

        # List of friends
        friends = db.execute("""SELECT users.username, users.pfp_url, users.id, friends.friend_date
                             FROM users JOIN friends ON users.id = friends.user_id
                             WHERE friends.friend_id = ? AND friends.pending = 0
                             ORDER BY friends.friend_date DESC""", user_id)

        # Number of incoming friend requests
        requests = db.execute("SELECT COUNT(user_id) FROM friends WHERE friend_id = ? AND pending = 1", user_id)[0]['COUNT(user_id)']

        return render_template("friends.html", friends=friends, requests=requests)

    if request.method == "POST":

        # List of friends
        friend = db.execute("SELECT id, username FROM users WHERE LOWER(username) = ?", request.form.get("friend").lower())

        # Alert if user input does not exist
        if not friend:
            flash("User does not exist", 'warning')
            return redirect("/friends")

        friend_id = friend[0]['id']

        # Alert if user input is the logged in user
        if user_id == friend_id:
            flash("Cannot add yourself", 'warning')
            return redirect("/friends")

        # Store info about input user if they have sent a request
        incoming_request = db.execute("SELECT user_id, pending FROM friends WHERE user_id = ? AND friend_id = ?", friend_id, user_id)

        # Alert if user needs to respond to request from the input user
        if incoming_request and incoming_request[0]['pending']:
            flash("Respond to " + friend[0]['username'] + "'s friend request", 'warning')
            return redirect("/friend-requests")

        # Store info about input user if already a friend/sent a request already
        potential_friend = db.execute("SELECT pending FROM friends WHERE user_id = ? AND friend_id = ?", user_id, friend_id)

        # Alert if friends already or the user sent a request already and has not received a response
        if potential_friend:
            if potential_friend[0]['pending']:
                flash("Request to " + friend[0]['username'] + " still pending", 'warning')
                return redirect("/friends")
            flash("You are already friends with " + friend[0]['username'] + "!", 'warning')
            return redirect("/friends")

        # Add info about friend request into database
        db.execute("INSERT INTO friends (user_id, friend_id) VALUES(?, ?)", user_id, friend[0]['id'])

        flash("Friend request sent to " + friend[0]['username'] + "!", 'success')

        return redirect("/friends")


@app.route("/user-history")
@login_required
def userHistory():
    """Redirect to logged in user's rating history"""

    # Logged in user's username
    username = db.execute("SELECT username FROM users WHERE id=?", session.get("user_id"))[0]['username']

    # User-reached route via GET
    return redirect("/history/" + username)


@app.route("/history/<username>", methods=["GET", "POST"])
@login_required
def history(username):
    """Show history of user's ratings"""

    # ID of user logged in
    loggedInUser = session.get("user_id")

    if request.method == "GET":
        # Get list containing dict with user_id
        users_list = db.execute("SELECT id FROM users WHERE username=?", username)

        # Check if username in database. If not, return 404 error page
        if not users_list:
            return render_template("404.html")

        # Dict containing info about user
        user_info = users_list[0]

        # Store whether username belongs to the user logged in
        isLoggedInUser = False

        # Check if username belongs to user logged in
        if user_info['id'] == loggedInUser:
            isLoggedInUser = True

        user_id = user_info['id']

        show_history = db.execute("SELECT anime.title, ratings.anime_id, ratings.rating, ratings.comment, ratings.time FROM ratings JOIN anime ON anime.id = ratings.anime_id WHERE user_id = ? ORDER BY time DESC", user_id)

        # User-reached route via GET
        return render_template("history.html", show_history=show_history, isLoggedInUser=isLoggedInUser, username=username)

    if request.method == "POST":

        anime_id = request.form.get("delete")

        # Delete entry in ratings corresponding to user_id and anime_id
        db.execute("DELETE FROM ratings WHERE user_id=? AND anime_id=?", loggedInUser, anime_id)

        # Update site-wide rating for title
        latest_rating = db.execute("SELECT ROUND(AVG(rating),2) FROM ratings WHERE anime_id=?", anime_id)
        db.execute("UPDATE anime SET rating = ? WHERE id=?", latest_rating[0]["ROUND(AVG(rating),2)"], anime_id)

        flash("Rating removed.", 'success')

        # User-reached route via POST
        return redirect("/history/" + username)



@app.route("/community")
@login_required
def community():
    """Show members of community"""

    # List of dicts containing info about each user
    users = db.execute("SELECT username, pfp_url, date_joined, substr(bio, 1, 200) AS bio FROM users ORDER BY LOWER(username)")

    # Change date to Month Day, Year format
    for user in users:
        user['date_joined'] = standard_date(user['date_joined'])

    # User-reached route via GET
    return render_template("/community.html", users=users)


@app.route("/user-profile")
@login_required
def userProfile():
    """Redirect to logged in user's profile"""

    # Logged in user's username
    username = db.execute("SELECT username FROM users WHERE id=?", session.get("user_id"))[0]['username']

    # User-reached route via GET
    return redirect("/profile/" + username)


@app.route("/profile/<username>")
@login_required
def profile(username):
    """Show user's profile"""

    # Get list containing dict with user_id
    users_list = db.execute("SELECT id FROM users WHERE username=?", username)

    # Check if username in database. If not, return 404 error page
    if not users_list:
        return render_template("404.html")

    # Dict containing info about user
    user_info = users_list[0]

    # Store whether username belongs to the user logged in
    isLoggedInUser = False

    # ID of user logged in
    loggedInUser = session.get("user_id")

    # Check if username belongs to user logged in
    if user_info['id'] == loggedInUser:
        isLoggedInUser = True

    user_id = user_info['id']

    # Dict containing info about user
    user_info = db.execute("SELECT username, bday, pfp_url, gender, bday, date_joined, bio FROM users WHERE id=?", user_id)[0]

    # Alter dates so written Month Day, Year
    user_info['bday'] = standard_date(user_info['bday'])
    user_info['date_joined'] = standard_date(user_info['date_joined'])

    # List of dicts with information about 5 of user's favorite anime
    favorites = db.execute("SELECT title, image_url FROM anime JOIN favorites ON anime.id=favorites.anime_id WHERE user_id=? ORDER BY rank LIMIT 5", user_id)

    # List of dicts with information about 3 most recent shows a user has rated
    show_history = db.execute("SELECT anime.title, ratings.rating, ratings.comment, ratings.time FROM ratings JOIN anime ON anime.id = ratings.anime_id WHERE user_id = ? ORDER BY time DESC LIMIT 3", user_id)

    # User-reached route via GET
    return render_template("profile.html", user_info=user_info, favorites=favorites, isLoggedInUser=isLoggedInUser, show_history=show_history)


@app.route("/edit-profile", methods=["GET", "POST"])
@login_required
def editProfile():
    """"Edit user's profile"""

    # ID of logged in user
    user_id = session.get("user_id")

    if request.method == "GET":

        # Info about user
        user_info = db.execute("SELECT username, date_joined, bday, pfp_url, gender, bio FROM users WHERE id = ?", user_id)[0]

        # User-reached route via GET
        return render_template("edit_profile.html", user_info=user_info, genders=GENDERS, current_date=CURRENT_DATE)

    if request.method == "POST":

        # Store info retrieved from form
        pfp_url = request.form.get("pfp")
        bio = request.form.get("bio")
        gender = request.form.get("gender")

        # Set bday to None if left empty by user
        birthday = request.form.get("birthday")
        bday =  birthday if birthday != "" else None

        # Update user info in database based on form
        db.execute("UPDATE users SET pfp_url=?, bio=?, bday=?, gender=? WHERE id=?", pfp_url, bio, bday, gender, user_id)

        # User-reached route via POST
        return redirect("/user-profile")


@app.route("/user-favorites")
@login_required
def userFavorites():
    """Redirect to logged in user's favorites list"""

    # Logged in user's username
    username = db.execute("SELECT username FROM users WHERE id=?", session.get("user_id"))[0]['username']

    # User-reached route via GET
    return redirect("/favorites/" + username)


@app.route("/favorites/<username>")
@login_required
def favorites(username):
    """List of favorite anime of specified user"""

    # List containing dict with id corresponding to username
    users_list = db.execute("SELECT id FROM users WHERE username=?", username)

    # Check if username in database. If not, return 404 error page
    if not users_list:
        return render_template("404.html")

    # Dict containing id of user
    user_info = users_list[0]

    # Store whether username belongs to the user logged in
    isLoggedInUser = False

    # ID of user logged in
    loggedInUser = session.get("user_id")

    # Check if username belongs to user logged in
    if user_info['id'] == loggedInUser:
        isLoggedInUser = True

    user_id = user_info['id']

    # List of dicts containing information about each favorite anime
    favorites = db.execute("SELECT title, image_url, season, episodes, genre FROM anime JOIN favorites ON anime.id=favorites.anime_id WHERE user_id=? ORDER BY rank", user_id)

    # User-reached route via GET
    return render_template("favorites.html", favorites=favorites, username=username, isLoggedInUser=isLoggedInUser)


@app.route("/title-search")
@login_required
def titleSearch():
    """Search for anime titles"""
    query = "%" + request.args.get("q") + "%"
    anime = db.execute("SELECT title, title_english FROM anime WHERE title LIKE ? OR title_english LIKE ? ORDER BY title LIMIT 15", query, query)
    return jsonify(anime)


@app.route("/user-search")
@login_required
def userSearch():
    """Search for users"""
    users = db.execute("SELECT username FROM users WHERE username LIKE ? ORDER BY username LIMIT 10", "%" + request.args.get("q") + "%")
    return jsonify(users)


@app.route("/add-favorites", methods=["GET", "POST"])
@login_required
def addFavorites():
    """Add anime to favorites list"""

    # ID of logged in user
    user_id = session.get("user_id")

    if request.method == "GET":

        # Retrieve the number of favorites a user has from database
        numFavorites = db.execute("SELECT MAX(rank) FROM favorites WHERE user_id=?", user_id)[0]['MAX(rank)']

        # User-reached route via GET
        return render_template("add_favorites.html", numFavorites=numFavorites, maxTitles=MAX_FAVORITES)

    if request.method == "POST":

        # Title entered by user in lowercase + remove english title if user used autocomplete
        title = request.form.get("favorite").lower().split(" (english: ")[0]

        # Retrieve list containing dict with info about anime matching title
        anime_list = db.execute("SELECT id, title, title_english FROM anime WHERE LOWER(title)=? OR LOWER(title_english)=?", title, title)

        # Check if title in database; error alert if not
        if not anime_list:
            flash("Invalid title. Please try again.", 'warning')
            return redirect("/add-favorites")

        # Dict containing info about anime
        anime = anime_list[0]

        # Title of anime (English if possible; if not, romanized Japanese)
        title = anime['title_english'] if anime['title_english'] != "" else anime['title']

        # Check if title already in user's favorites list; error alert if already added
        if db.execute("SELECT anime_id FROM favorites WHERE anime_id=? AND user_id=?", anime['id'], user_id):
            flash("You already added " + title + "!", 'warning')
            return redirect("/add-favorites")

        # Alert user that title has been added to favorites
        flash("Added " + title + "!", 'success')

        # Insert info about anime into favorites table
        db.execute("INSERT INTO favorites (user_id, anime_id, rank) VALUES(?, ?, ?)", user_id, anime['id'], request.form.get("rank"))

        # User-reached route via POST
        return redirect("/add-favorites")


@app.route("/remove-favorites", methods=["GET", "POST"])
@login_required
def removeFavorites():
    """"Remove anime from favorites list"""

    # ID of logged in user
    user_id = session.get("user_id")

    if request.method == "GET":

        # List of dicts containing info about each of user's favorite anime
        favorites = db.execute("SELECT title, id FROM anime JOIN favorites ON anime.id=favorites.anime_id WHERE user_id=? ORDER BY rank", user_id)

        # User-reached route via GET
        return render_template("remove_favorites.html", favorites=favorites)

    if request.method == "POST":

        # ID of anime that user chose
        anime_id = request.form.get("id_remove")

        # Check if title selected; if not, error alert
        if anime_id is None:
            flash("Please select a title.", 'warning')
            return redirect("/remove-favorites")

        # Retrieve title corresponding to anime ID
        title = db.execute("SELECT title FROM anime WHERE id=?", anime_id)[0]['title']

        # Alert that anime removed from favorites
        flash("Removed " + title + "!", 'success')

        # Retrieve rank of anime to be removed
        rank = db.execute("SELECT rank FROM favorites WHERE user_id=? AND anime_id=?", user_id, anime_id)[0]['rank']

        # Delete entry in favorites corresponding to user_id and anime_id
        db.execute("DELETE FROM favorites WHERE user_id=? AND anime_id=?", user_id, request.form.get("id_remove"))

        # Update ranks of other favorites corresponding to the user_id in favorites table in database
        for i in range(rank, MAX_FAVORITES):
            db.execute("UPDATE favorites SET rank=? WHERE user_id=? AND rank=?", i, user_id, i + 1)

        # User-reached route via POST
        return redirect("/remove-favorites")


@app.route("/")
@login_required
def index():
    shows = db.execute("SELECT title, image_url, genre, episodes, rating FROM anime ORDER BY rating DESC LIMIT 10")
    return render_template("top_ten.html", shows=shows)


@app.route("/rate", methods=["GET", "POST"])
@login_required
def rate():
    user_id = session.get("user_id")
    if request.method == "GET":
        return render_template("rate.html")

    # check for invalid inputs
    user_rating = int(request.form.get("rate"))

    # Title entered by user in lowercase + remove english title if user used autocomplete
    title = request.form.get("title").lower().split(" (english: ")[0]

    comment = request.form.get("comment")

    # check if title exists (case insensitive)
    check_title = db.execute("SELECT title, id FROM anime WHERE LOWER(title) = ? OR LOWER(title_english) = ?", title, title)
    if not check_title:
        flash("Invalid title. Please try again.",'warning')
        return render_template("rate.html")

    title_id = check_title[0]["id"]

    # update user rating if already rated before
    rated = db.execute("SELECT rating FROM ratings WHERE anime_id = ? AND user_id=?", title_id, user_id)
    if not rated:
        db.execute("INSERT INTO ratings (user_id, anime_id, rating, comment) VALUES (?, ?, ?, ?)",
               user_id, title_id, user_rating, comment)
    else:
        db.execute("UPDATE ratings SET rating=?, comment=?, time=CURRENT_TIMESTAMP WHERE anime_id=? AND user_id=?", user_rating, comment, title_id, user_id)

    latest_rating = db.execute("SELECT ROUND(AVG(rating),2) FROM ratings WHERE anime_id=?", title_id)
    db.execute("UPDATE anime SET rating = ? WHERE id=?", latest_rating[0]["ROUND(AVG(rating),2)"], title_id)
    return redirect("/")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted; error alert if not
        if not request.form.get("username"):
            flash("Please enter a username", 'danger')
            return redirect("/login")

        # Ensure password was submitted; error alert if not
        elif not request.form.get("password"):
            flash("Please enter a password", 'danger')
            return redirect("/login")

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct; error alert if not
        if len(rows) != 1 or not check_password_hash(rows[0]['hash'], request.form.get("password")):
            flash("Invalid username and/or password", 'danger')
            return redirect("/login")

        # Remember which user has logged in
        session['user_id'] = rows[0]['id']

        # Redirect user to home page
        return redirect("/")

    # User-reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":

        # Get info
        email = request.form.get("email")
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

        # Update taken based on whether username taken or not
        username_list = db.execute("SELECT username FROM users")
        taken = False
        for user in username_list:
            if user['username'] == username:
                taken = True
                break

        # Alert if no username provided or taken
        if not username or taken:
            flash("Username taken or left blank.", 'danger')
            return redirect("/register")

        # Alert if username over 20 characters
        if len(username) > 20:
            flash("Username cannot be over 20 characters.", 'danger')
            return redirect("/register")

        # Alert if password over 20 characters
        if len(password) > 20:
            flash("Password cannot be over 20 characters.", 'danger')
            return redirect("/register")

        # Alert if no password provided or password doesn't match confirmation
        if not password or password != confirmation:
            flash("Password left blank or passwords do not match.", 'danger')
            return redirect("/register")

        # Check if email address valid; alert if invalid
        emailAddress = email.split("@")

        if len(emailAddress) != 2 or not emailAddress[0].isalnum():
             flash("Enter a valid email address.", 'danger')
             return redirect("/register")

        emailDomain = emailAddress[1].split(".")

        if len(emailDomain) != 2 or not emailDomain[0].isalnum() or not emailDomain[1].isalnum():
            flash("Enter a valid email address.", 'danger')
            return redirect("/register")

        # Hash password
        pass_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)

        # Add username and password to database
        db.execute("INSERT INTO users (username, hash, email) VALUES(?, ?, ?)", username, pass_hash, email)

        # Alert user that they registered
        flash("Successfully registered!", 'success')

        # Redirect to login / User-reached route via POST
        return redirect("/login")

    # User-reached route via GET
    else:
        return render_template("register.html")


@app.route("/new_password", methods=["GET", "POST"])
def new_password():

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        username = request.form.get("username")
        # Query database for username
        if not username:
            flash("Username Required", 'danger')
            return render_template("new_password.html")

        rows = db.execute("SELECT username, hash FROM users WHERE username = ?", username)

        # Ensure username and old password exists
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("old_password")):
            flash("Invalid username and/or password", 'danger')
            return render_template("new_password.html")

        # Check if the NEW passwords match
        if request.form.get("new_password") != request.form.get("confirm"):
            flash("New passwords do not match", 'warning')
            return render_template("new_password.html")

        # Update the hashed password in the database
        hash_password = generate_password_hash(request.form.get("new_password"))
        db.execute("UPDATE users SET hash = ? WHERE username = ?", hash_password, username)

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking the Change Password button)
    else:
        return render_template("new_password.html")


@app.route("/forgot_password", methods=["GET", "POST"])
def forgot_password():
# User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        username = request.form.get("username")
        email = request.form.get("email")
        # Query database for username
        if not username:
            flash("Username Required", 'danger')
            return render_template("forgot_password.html")

        user_info = db.execute("SELECT username, email FROM users WHERE username = ? AND email = ?", username, email)

        # Ensure username and old password exists
        if not user_info:
            flash("Username or email is incorrect!", 'danger')
            return render_template("forgot_password.html")

        # create temporary password
        pwo = PasswordGenerator()
        pwo.minlen = 6
        pwo.maxlen = 15
        # length of required password
        temp = pwo.generate()

        # Update the hashed password in the database
        hash_password = generate_password_hash(temp)
        db.execute("UPDATE users SET hash = ? WHERE username = ?", hash_password, username)

        # send email notification about registration
        ####message = Message("You are registered!", recipients=[email])
        ####mail.send(message)

        flash("temp password " + temp + " sent!", 'success')
        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking the Change Password button)
    else:
        return render_template("forgot_password.html")



@app.route("/watch-party", methods=["GET", "POST"])
@login_required
def watchparty_request():

    # User reached route via POST (as by submitting a form via POST)
    user_id = session.get("user_id")
    friend_usernames=db.execute("SELECT username FROM users WHERE id IN (SELECT friend_id FROM friends WHERE user_id = ? AND pending = 0) ORDER BY LOWER(username) ASC", user_id)

    if request.method == "POST":

    # User-reached route via GET (as by clicking a link or via redirect)
        # Title entered by user in lowercase + remove english title if user used autocomplete
        room_link = request.form.get("room_link")
        date = request.form.get("watch_date")
        time = request.form.get("watch_time")

        if not request.form.get("friend"):
            flash("Enter a username!", 'warning')
            return redirect("/watch-party")

        friend = request.form.get("friend").lower()

        if "https://app.kosmi.io/room/" not in room_link:
            flash("Enter a valid link!", 'warning')
            return redirect("/watch-party")

        # Retrieve list containing dict with info about anime matching title
        ### friend_list = db.execute("SELECT username FROM users WHERE id IN (SELECT friend_id FROM friends WHERE user_id=?)", 9)
        friend_list = db.execute("SELECT username FROM users WHERE LOWER(username)=? AND id IN (SELECT friend_id FROM friends WHERE user_id = ? AND pending = 0)", friend, user_id)

        # Check if title in database; error alert if not
        if not friend_list:
            flash("Invalid friend username!", 'warning')
            return redirect("/watch-party")

        # friend list
        friends = friend_list[0]["username"]

        # Alert user that title has been added to favorites
        flash("Invitation sent to " + friends + "! Link: " + room_link, 'success')

        # send email to friend with a link to the event

        # User-reached route via POST
        return render_template("watchparty.html", friend_usernames=friend_usernames)
    else:
        # Redirect user to home page
        return render_template("watchparty.html", friend_usernames=friend_usernames, current_date=CURRENT_DATE)


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    if e.code == 404:
        return render_template("404.html")
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
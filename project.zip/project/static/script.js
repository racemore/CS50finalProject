
// Search for anime titles function
function search(input_id) {
    let input = document.querySelector(input_id);

    input.addEventListener('keyup', function() {
        $.get('/search?q=' + input.value, function(anime) {
            let html = '';
            for (let id in anime)
            {
                let title = anime[id].title;
                let titleEn = anime[id].title_english;
                if (titleEn.localeCompare("") != 0 && titleEn.localeCompare(title) != 0)
                {
                    html += '<option value="' + title + ' (English: ' + titleEn + ')">';
                }
                else
                {
                    html += '<option value="' + title + '">';
                }
            }
            document.querySelector('#lists').innerHTML = html;
        });
    });
}


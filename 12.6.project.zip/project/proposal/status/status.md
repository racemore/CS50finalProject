# Status Report

#### Your name

Ashleigh Coltman and Aracely Moreno

#### Your section leader's name

Ashley Zhuang and Jonny Zhang

#### Project title

WeebTube

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

Ashleigh: Users can register and log into their accounts. In addition, users can access and edit their profile. Profiles contain a profile picture, bio, the date the user joined the site, the user’s birthday and gender, and five of their favorite anime. A user can also view a table of their favorite anime with each row containing the cover, title, season aired, and genres of an anime on their favorites page. The add and remove favorites function has been implemented. In order to add to their favorites, on the Add Favorites page, users can enter a title in romanized Japanese or English without worrying about case-sensitivity. To remove a show from their favorites, users can select the show they wish to remove from a drop down menu on the Remove Favorites page. Currently, users can only add 20 titles to their favorites. Moreover, users can see a table of the other users on the site and visit another user’s profile on the Community page. Users can also view another user’s complete list of favorite anime by clicking on the “View All” button on that particular user’s profile.
Aracely: Users can also choose to change their password given that the user remembers their current username and password.
We have a "Rate A Show" page where the user can type any title in Japanese or English (case insensitive) into the rate input box. Only the shows displayed within the MyAnimeList Dataset from 2018 (https://www.kaggle.com/azathoth42/myanimelist) are considered in the website. Next, the user can give an integer value 0 through 10, inclusive, and an optional comment up to 200 characters. This information is stored in the weebtube database, specifically into a table called ratings, which stores the rating integer, comment, user_id, and anime_id. Error checks are implemented to ensure that the user provides a valid title and rating.
In the "Rating History" page, the user can visualize the shows they have already rated. Information in the history table includes the anime title, the user's rating, comments, and the timestamp of the rating. When a user rates a new show, the new line is added to the top of the table. Additionally, if the user tries to rate a show that they have already rated, the website updates the ratings table from the weebtube database to alter the rating value, timestamp, and comment with the new inputs. The updated show rating will appear at the top of the history page.
The "Top 10 Shows" or homepage displays the 10 most highly rated shows according to users on the website. This page displays the title, cover image, genre, number of episodes, and average rating based on all the ratings from users on the site for each show. The average rating updates after each user rating to keep the displayed information up-to-date with the database values.

#### What have you not done for your project yet?

We have not yet implemented the watch party feature. This feature would allow users to create a watch party and invite other users to watch a show through an external website at a specific date. All info pertaining to each watch party would be sent through email to the users involved. In addition, we need to add further error checking and improve the aesthetics/layout of the site so that it no longer looks like Finance. Furthermore, we need to implement a “forgot password” feature and potentially update searching on our site so that suggestions appear as a user types their search.

#### What problems, if any, have you encountered?

We were having problems with creating an advanced search engine that updates with each character the user types for an anime title. This function would allow users to not type the entire title, but we decided to resolve this issue at a later date.

